# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

"""Utilities for loading checkpoints."""

from typing import Any

import numpy as np


def npload(fname: str) -> dict[str, np.ndarray]:
  """Read a non-pickled NPZ checkpoint and release its file descriptor.

  Rejects plain NPY files to keep the return contract consistently mapping
  string parameter names to independent, fully materialized arrays.
  """
  loaded = np.load(fname, allow_pickle=False)
  if not isinstance(loaded, np.lib.npyio.NpzFile):
    raise ValueError('Expected an NPZ checkpoint archive')
  with loaded:
    return {name: loaded[name] for name in loaded.files}


def recover_tree(flat_dict: dict[str, np.ndarray]) -> dict[str, Any]:
  """Recover a nested parameter tree without ambiguous key collisions.

  An existing leaf may not become a branch (or vice versa). Empty path
  segments are rejected rather than silently becoming dictionary keys.
  """
  tree: dict[str, Any] = {}
  for path, value in flat_dict.items():
    if not isinstance(path, str) or not path:
      raise ValueError('Checkpoint path must be a nonempty string')
    parts = path.split('/')
    if any(not part or part in ('.', '..') for part in parts):
      raise ValueError(f'Invalid checkpoint path: {path!r}')
    node = tree
    for part in parts[:-1]:
      if part not in node:
        node[part] = {}
      if not isinstance(node[part], dict):
        raise ValueError(f'Checkpoint path collision: {path!r}')
      node = node[part]
    leaf = parts[-1]
    if leaf in node:
      raise ValueError(f'Checkpoint path collision: {path!r}')
    node[leaf] = value
  return tree
