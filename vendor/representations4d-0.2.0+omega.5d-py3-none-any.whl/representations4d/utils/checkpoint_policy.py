"""Fail-closed, optional SHA-256 verification for GenCeption model artifacts.

This is independent of JAX/Flax and runs before multi-gigabyte model allocation.
Manifest schema (if present): {"sha256": {"relative/path": "64 hex chars"}}.
A manifest is not a signature; authenticate the manifest through a trusted
channel before treating hashes as provenance evidence.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re


def sha256_file(path: Path, chunk_size: int = 4 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def validate_genception_artifacts(
    checkpoint_dir: str | os.PathLike[str],
    model_size: str,
    *,
    allow_random_init: bool = False,
    manifest_name: str = 'sha256-manifest.json',
) -> dict[str, Path]:
    """Verify required model artifacts before initializing JAX model state.

    Random initialization is an explicitly opted-in debugging mode, not
    a successful pretrained inference. Existing manifest is verified strictly.
    """
    if model_size not in ('1.3b', '14b'):
        raise ValueError('model_size must be 1.3b or 14b')
    root = Path(checkpoint_dir).expanduser().resolve()
    if not root.is_dir():
        raise FileNotFoundError(f'Checkpoint directory not found: {root}')
    expected = {
        'transformer': f'genception_{model_size}_transformer.npz',
        'vae': 'vae/diffusion_pytorch_model.safetensors',
    }
    paths: dict[str, Path] = {}
    for role, rel in expected.items():
        candidate = root / rel
        resolved = candidate.resolve()
        if not resolved.is_relative_to(root):
            raise ValueError(f'Checkpoint path escapes root: {rel}')
        if candidate.is_file() and candidate.stat().st_size > 0:
            paths[role] = candidate
        elif not allow_random_init:
            raise FileNotFoundError(f'Required {role} weights missing or empty: {candidate}')

    manifest_path = root / manifest_name
    if manifest_path.exists():
        if not manifest_path.is_file() or manifest_path.is_symlink():
            raise ValueError('Checksum manifest must be a regular file')
        with manifest_path.open('r', encoding='utf-8') as f:
            manifest = json.load(f)
        if not isinstance(manifest, dict) or not isinstance(manifest.get('sha256'), dict):
            raise ValueError('Invalid SHA-256 manifest schema')
        hashes = manifest['sha256']
        for role, rel in expected.items():
            if role not in paths:
                continue
            checksum = hashes.get(rel)
            if not isinstance(checksum, str) or not re.fullmatch(r'[a-fA-F0-9]{64}', checksum):
                raise ValueError(f'Missing or invalid SHA-256 checksum for {rel}')
            if sha256_file(paths[role]) != checksum.lower():
                raise ValueError(f'SHA-256 checksum mismatch for {rel}')
    return paths


from dataclasses import dataclass
from typing import Any, Mapping
import math


@dataclass(frozen=True)
class CheckpointAudit:
    """Checkpoint-to-model matching report, before any model state is updated."""

    matched: tuple[tuple[str | int, ...], ...]
    missing: tuple[tuple[str | int, ...], ...]
    unexpected: tuple[str, ...]
    shape_mismatches: tuple[tuple[str, tuple[int, ...], tuple[int, ...]], ...]
    duplicate_paths: tuple[str, ...]

    def require_complete(self) -> None:
        if self.missing or self.unexpected or self.shape_mismatches or self.duplicate_paths:
            raise ValueError(
                'Checkpoint does not match model: '
                f'{len(self.missing)} missing, {len(self.unexpected)} unexpected, '
                f'{len(self.shape_mismatches)} shape mismatches, '
                f'{len(self.duplicate_paths)} duplicate aliases. '
                f'Examples: missing={self.missing[:3]}, '
                f'unexpected={self.unexpected[:3]}, '
                f'mismatch={self.shape_mismatches[:3]}'
            )


def _checkpoint_key(path: str) -> tuple[str | int, ...]:
    if not isinstance(path, str) or not path:
        raise ValueError('Checkpoint key must be nonempty string')
    parts = path.split('.')
    if parts[-1] == 'value':
        parts = parts[:-1]
    if not parts or any(not p for p in parts):
        raise ValueError(f'Invalid checkpoint parameter path: {path!r}')
    return tuple(int(p) if p.isdigit() else p for p in parts)


def audit_checkpoint_shapes(
    expected: Mapping[tuple[str | int, ...], tuple[int, ...]],
    checkpoint: Mapping[str, Any],
) -> CheckpointAudit:
    """Audit key/shape compatibility without importing or allocating JAX."""
    seen: set[tuple[str | int, ...]] = set()
    matched: list[tuple[str | int, ...]] = []
    unexpected: list[str] = []
    mismatches: list[tuple[str, tuple[int, ...], tuple[int, ...]]] = []
    duplicates: list[str] = []
    for name, value in checkpoint.items():
        key = _checkpoint_key(name)
        if key in seen:
            duplicates.append(name)
            continue
        seen.add(key)
        if key not in expected:
            unexpected.append(name)
            continue
        shape = tuple(value.shape)
        if shape != tuple(expected[key]):
            mismatches.append((name, shape, tuple(expected[key])))
        else:
            matched.append(key)
    return CheckpointAudit(
        tuple(matched), tuple(k for k in expected if k not in seen),
        tuple(unexpected), tuple(mismatches), tuple(duplicates),
    )


def validate_config_overrides(defaults: Mapping[str, Any], overrides: Any) -> dict:
    """Reject unknown, non-finite and type-incompatible model config overrides."""
    if not isinstance(overrides, dict):
        raise ValueError('Model configuration overrides must be a JSON object')
    result = dict(defaults)
    for key, value in overrides.items():
        if key not in defaults:
            raise ValueError(f'Unknown model config key: {key}')
        original = defaults[key]
        if isinstance(original, bool):
            valid = isinstance(value, bool)
        elif isinstance(original, int):
            valid = (type(value) is int and
                     (value >= 0 if key == 'diffusion_single_step' else value > 0))
        elif isinstance(original, float):
            valid = (type(value) in (int, float) and
                     math.isfinite(value) and value > 0)
        elif isinstance(original, str):
            valid = isinstance(value, str) and bool(value)
        else:
            valid = type(value) is type(original)
        if not valid:
            raise ValueError(f'Invalid value for model config key {key!r}: {value!r}')
        result[key] = value
    return result
