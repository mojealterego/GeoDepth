# SPDX-License-Identifier: Apache-2.0
"""Lift explicitly metric RGB-D observations into X,Y,Z,time,log-scale.

The footprint estimate is the geometric-mean *one pixel* pinhole footprint
at optical depth Z, not a depth uncertainty or a measured surface area.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from representations4d.geometry import (CameraIntrinsics, DepthFrame, DepthKind,
                                         RigidTransform, backproject)
from .field import _positive_float, _positive_int


@dataclass(frozen=True)
class ObservationBatch5D:
    coordinates: np.ndarray  # [N,5]
    values: np.ndarray  # [N,C]
    confidence: np.ndarray  # [N], [0,1]


def lift_metric_rgbd(
    frame: DepthFrame, camera: CameraIntrinsics, world_from_camera: RigidTransform,
    time_seconds: float, reference_radius_m: float, *,
    features: np.ndarray | None = None, confidence_map: np.ndarray | None = None,
    stride: int = 1, max_points: int = 100_000,
) -> ObservationBatch5D:
    """Deterministically unproject metric depth into world XYZ, time and scale.

    The features default to observed occupancy=1, not inferred color/density.
    The caller must supply consistent world poses and timestamps.
    """
    if not isinstance(frame, DepthFrame) or frame.kind is not DepthKind.METRIC:
        raise ValueError('5D fusion requires explicitly metric DepthFrame')
    if not isinstance(camera, CameraIntrinsics) or not isinstance(world_from_camera, RigidTransform):
        raise ValueError('CameraIntrinsics and RigidTransform are required')
    radius_ref = _positive_float('reference_radius_m', reference_radius_m)
    if isinstance(time_seconds, (bool, np.bool_)):
        raise ValueError('time_seconds must be finite')
    time = float(time_seconds)
    if not np.isfinite(time):
        raise ValueError('time_seconds must be finite')
    stride = _positive_int('stride', stride, 1_000_000)
    max_points = _positive_int('max_points', max_points, 1_000_000)
    h, w = frame.values.shape
    if (h, w) != (camera.height, camera.width):
        raise ValueError('Depth and camera resolutions differ')
    if features is None:
        feat = None
    else:
        feat = np.asarray(features)
        if (feat.ndim != 3 or feat.shape[:2] != (h, w) or
            not 1 <= feat.shape[2] <= 256 or feat.dtype.kind not in 'fiu'):
            raise ValueError('features must be numeric [H,W,C], 1<=C<=256')
    if confidence_map is None:
        confidence = np.ones((h, w), dtype=np.float64)
    else:
        confidence = np.asarray(confidence_map)
        if (confidence.shape != (h, w) or confidence.dtype.kind not in 'fiu' or
            not np.isfinite(confidence).all() or np.any(confidence < 0) or
            np.any(confidence > 1)):
            raise ValueError('confidence_map must be finite [H,W] in [0,1]')
        confidence = confidence.astype(np.float64)
    # Mask 0-confidence pixels *before* limiting point count.
    good_frame = DepthFrame(frame.values, DepthKind.METRIC,
                            mask=frame.mask & (confidence > 0))
    cloud = backproject(good_frame, camera, stride=stride, max_points=max_points)
    u = cloud.uv[:, 0].astype(int)
    v = cloud.uv[:, 1].astype(int)
    if feat is None:
        values = np.ones((len(u), 1), dtype=np.float64)
    else:
        values = np.asarray(feat[v, u], dtype=np.float64)
        if not np.isfinite(values).all():
            raise ValueError('Selected feature pixels must be finite')
    xyz_world = world_from_camera.apply(cloud.xyz)
    footprint_m = cloud.xyz[:, 2] / np.sqrt(camera.fx * camera.fy)
    scale = np.log2(footprint_m / radius_ref)
    coordinates = np.column_stack((xyz_world,
                                   np.full(len(u), time, dtype=np.float64), scale))
    if not np.isfinite(coordinates).all():
        raise ValueError('Five-dimensional coordinates overflowed')
    return ObservationBatch5D(coordinates, values, confidence[v, u])
