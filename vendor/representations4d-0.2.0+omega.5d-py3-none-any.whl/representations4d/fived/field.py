# SPDX-License-Identifier: Apache-2.0
"""Bounded, deterministic NumPy sparse 5D field (X,Y,Z,time,log2-footprint).

The fifth coordinate is observational scale, not an additional physical axis.
Units are meters, meters, meters, seconds, log2(radius_m / reference_m).
A sparse field stores only populated lattice vertices, not the dense 5D grid.

This is an explicit, non-neural reconstruction layer. Nothing in this module
learns a radiance field or establishes the accuracy of external depth inputs.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from math import prod

import numpy as np

AXIS_NAMES = ('x_m', 'y_m', 'z_m', 'time_s', 'log2_footprint_ratio')
_CORNERS = np.asarray(list(product((0, 1), repeat=5)), dtype=np.int64)
_CHUNK = 1024
_DEFAULT_MAX_SAMPLES = 100_000
_DEFAULT_MAX_CELLS = 250_000
_MAX_CHANNELS = 256


def _positive_float(name: str, val: float) -> float:
    if isinstance(val, (bool, np.bool_)):
        raise ValueError(f'{name} must be finite and positive')
    try:
        number = float(val)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f'{name} must be finite and positive') from exc
    if not np.isfinite(number) or number <= 0:
        raise ValueError(f'{name} must be finite and positive')
    return number


def _positive_int(name: str, val: int, ceiling: int) -> int:
    if isinstance(val, (bool, np.bool_)) or not isinstance(val, (int, np.integer)) or not 1 <= val <= ceiling:
        raise ValueError(f'{name} must be an integer in [1,{ceiling}]')
    return int(val)


def _matrix(name: str, val: np.ndarray, width: int, *, allow_empty: bool = True) -> np.ndarray:
    arr = np.asarray(val)
    if arr.ndim != 2 or arr.shape[1] != width or (not allow_empty and arr.shape[0] == 0):
        raise ValueError(f'{name} must be [N,{width}]')
    if arr.dtype.kind not in 'fiu' or not np.isfinite(arr).all():
        raise ValueError(f'{name} must contain finite real numbers')
    return np.asarray(arr, dtype=np.float64)


@dataclass(frozen=True)
class Axis5D:
    origin: float
    step: float
    count: int

    def __post_init__(self) -> None:
        try:
            origin = float(self.origin)
        except (ValueError, TypeError, OverflowError) as exc:
            raise ValueError('axis origin must be finite') from exc
        if isinstance(self.origin, (bool, np.bool_)) or not np.isfinite(origin):
            raise ValueError('axis origin must be finite')
        step = _positive_float('axis step', self.step)
        count = _positive_int('axis count', self.count, 1_000_000)
        if count < 2 or not np.isfinite(origin + (count - 1) * step):
            raise ValueError('axis must have >=2 nodes and a finite endpoint')
        object.__setattr__(self, 'origin', origin)
        object.__setattr__(self, 'step', step)
        object.__setattr__(self, 'count', count)


@dataclass(frozen=True)
class GridSpec5D:
    axes: tuple[Axis5D, ...]
    reference_radius_m: float

    def __post_init__(self) -> None:
        axes = tuple(self.axes)
        if len(axes) != 5 or not all(isinstance(axis, Axis5D) for axis in axes):
            raise ValueError('Exactly five Axis5D objects required')
        shape = tuple(a.count for a in axes)
        if prod(shape) > np.iinfo(np.int64).max:
            raise ValueError('5D lattice cannot be indexed safely in int64')
        object.__setattr__(self, 'axes', axes)
        object.__setattr__(self, 'reference_radius_m',
                           _positive_float('reference_radius_m', self.reference_radius_m))

    @property
    def shape(self) -> tuple[int, ...]:
        return tuple(a.count for a in self.axes)

    def _fractional_nodes(self, coords: np.ndarray, *, require_inside: bool) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        points = _matrix('coordinates', coords, 5)
        base_origin = np.array([a.origin for a in self.axes])
        steps = np.array([a.step for a in self.axes])
        last = np.array([a.count - 1 for a in self.axes], dtype=np.float64)
        lattice = (points - base_origin) / steps
        if not np.isfinite(lattice).all():
            raise ValueError('Coordinate conversion overflow')
        inside = ((lattice >= -1e-10) & (lattice <= last + 1e-10)).all(axis=1)
        if require_inside and not inside.all():
            raise ValueError('Sample coordinates outside declared 5D grid')
        lattice = np.clip(lattice, 0, last)
        lower = np.floor(lattice).astype(np.int64)
        fraction = lattice - lower
        return lower, fraction, inside


@dataclass(frozen=True)
class QueryResult5D:
    values: np.ndarray
    coverage: np.ndarray
    mass: np.ndarray
    supported: np.ndarray


@dataclass(frozen=True)
class SparseField5D:
    """Immutable sorted sparse node table, each node storing weighted means.

    mass is accumulated confidence (sample weights), not a probability.
    coverage is the sum of the multilinear stencil weights of known nodes.
    Unknown regions produce NaN, never extrapolated values.
    """
    grid: GridSpec5D
    indices: np.ndarray  # [K], strictly ascending flattened int64 node indices
    values: np.ndarray   # [K,C], weighted mean of splatted observations
    mass: np.ndarray     # [K], total nonnegative confidence mass

    def __post_init__(self) -> None:
        if not isinstance(self.grid, GridSpec5D):
            raise ValueError('Invalid 5D grid')
        keys = np.asarray(self.indices)
        features = np.asarray(self.values)
        mass = np.asarray(self.mass)
        if keys.ndim != 1 or keys.dtype.kind not in 'iu' or mass.shape != keys.shape:
            raise ValueError('Invalid sparse index/mass arrays')
        if features.ndim != 2 or features.shape[0] != keys.size or not (1 <= features.shape[1] <= _MAX_CHANNELS):
            raise ValueError('Invalid sparse feature dimensions')
        if features.dtype.kind not in 'fiu' or mass.dtype.kind not in 'fiu':
            raise ValueError('Sparse features and mass must be real')
        keys = keys.astype(np.int64, copy=True)
        features = features.astype(np.float64, copy=True)
        mass = mass.astype(np.float64, copy=True)
        if (np.any(keys < 0) or np.any(keys >= prod(self.grid.shape)) or
            np.any(np.diff(keys) <= 0) or not np.isfinite(features).all() or
            not np.isfinite(mass).all() or np.any(mass <= 0)):
            raise ValueError('Sparse cells must be unique, sorted, finite and supported')
        for arr in (keys, features, mass):
            arr.setflags(write=False)
        object.__setattr__(self, 'indices', keys)
        object.__setattr__(self, 'values', features)
        object.__setattr__(self, 'mass', mass)

    @property
    def active_cells(self) -> int:
        return len(self.indices)

    @classmethod
    def fit(cls, grid: GridSpec5D, coordinates: np.ndarray, values: np.ndarray,
            confidence: np.ndarray | None = None, *,
            max_samples: int = _DEFAULT_MAX_SAMPLES,
            max_active_cells: int = _DEFAULT_MAX_CELLS) -> SparseField5D:
        """Confidence-weighted 5D multilinear splatting with bounded allocations.

        No weights or values are invented for unobserved cells. Sample positions
        must lie in the grid; rejected positions are *not* clamped to the edge.
        """
        max_samples = _positive_int('max_samples', max_samples, 1_000_000)
        max_active_cells = _positive_int('max_active_cells', max_active_cells, 2_000_000)
        if not isinstance(grid, GridSpec5D):
            raise ValueError('GridSpec5D required')
        points = _matrix('coordinates', coordinates, 5)
        feats = np.asarray(values)
        if (feats.ndim != 2 or feats.shape[0] != len(points) or
            not (1 <= feats.shape[1] <= _MAX_CHANNELS) or
            feats.dtype.kind not in 'fiu' or not np.isfinite(feats).all()):
            raise ValueError('Feature values must be finite real [N,C], 1<=C<=256')
        feats = feats.astype(np.float64)
        if len(points) > max_samples:
            raise MemoryError(f'{len(points)} observations exceed max_samples={max_samples}')
        if confidence is None:
            weights = np.ones(len(points))
        else:
            weights = np.asarray(confidence)
            if (weights.shape != (len(points),) or weights.dtype.kind not in 'fiu' or
                not np.isfinite(weights).all() or np.any(weights < 0) or
                np.any(weights > 1)):
                raise ValueError('Confidence must be finite [N] in [0,1]')
            weights = weights.astype(np.float64)
        # index -> (weighted feature sums, accumulated mass). O(active nodes).
        accum: dict[int, tuple[np.ndarray, float]] = {}
        for start in range(0, len(points), _CHUNK):
            stop = min(start + _CHUNK, len(points))
            lower, frac, _ = grid._fractional_nodes(points[start:stop], require_inside=True)
            # [B,32,5] corners, [B,32] shape weights.
            nodes = lower[:, None, :] + _CORNERS[None, :, :]
            factors = np.where(_CORNERS[None, :, :] == 1,
                               frac[:, None, :], 1. - frac[:, None, :])
            stencil = np.prod(factors, axis=-1) * weights[start:stop, None]
            allowed = (nodes < np.asarray(grid.shape)[None, None, :]).all(axis=2)
            active = allowed & (stencil > 0)
            if not active.any():
                continue
            idx = np.ravel_multi_index(nodes[active].T, grid.shape)
            w = stencil[active]
            vals = np.broadcast_to(feats[start:stop, None, :],
                                   (stop-start, 32, feats.shape[1]))[active]
            uniq, inv = np.unique(idx, return_inverse=True)
            total_weight = np.bincount(inv, weights=w, minlength=len(uniq))
            total_feat = np.column_stack([
                np.bincount(inv, weights=w * vals[:, c], minlength=len(uniq))
                for c in range(feats.shape[1])
            ])
            if not np.isfinite(total_feat).all() or not np.isfinite(total_weight).all():
                raise ValueError('Accumulation overflow')
            for i, key in enumerate(uniq):
                k = int(key)
                if k in accum:
                    old_sum, old_mass = accum[k]
                    new_mass = old_mass + total_weight[i]
                    new_sum = old_sum + total_feat[i]
                    if not np.isfinite(new_mass) or not np.isfinite(new_sum).all():
                        raise ValueError('Accumulation overflow')
                    accum[k] = (new_sum, new_mass)
                else:
                    if len(accum) >= max_active_cells:
                        raise MemoryError(f'Number of sparse cells exceeds {max_active_cells}')
                    accum[k] = (total_feat[i], float(total_weight[i]))
        ordered = sorted(accum)
        keys = np.asarray(ordered, dtype=np.int64)
        if ordered:
            mass = np.asarray([accum[k][1] for k in ordered])
            means = np.stack([accum[k][0] for k in ordered]) / mass[:, None]
        else:
            mass = np.empty((0,), dtype=np.float64)
            means = np.empty((0, feats.shape[1]), dtype=np.float64)
        return cls(grid, keys, means, mass)

    def query(self, coordinates: np.ndarray) -> QueryResult5D:
        """Confidence-weighted 32-corner interpolation with strict missingness.

        Returned support/coverage are observation properties, not calibrated
        epistemic uncertainty. Out-of-grid requests get NaNs, coverage=0.
        """
        points = _matrix('coordinates', coordinates, 5)
        if len(points) > _DEFAULT_MAX_SAMPLES:
            raise MemoryError('Too many queries in one call (max 100000)')
        result = np.full((len(points), self.values.shape[1]), np.nan)
        coverage = np.zeros(len(points), dtype=np.float64)
        mass_out = np.zeros(len(points), dtype=np.float64)
        if not self.active_cells or not len(points):
            return QueryResult5D(result, coverage, mass_out, coverage > 0)
        for start in range(0, len(points), _CHUNK):
            end = min(start + _CHUNK, len(points))
            lower, frac, inside = self.grid._fractional_nodes(points[start:end], require_inside=False)
            if not inside.any():
                continue
            lower = lower[inside]
            frac = frac[inside]
            nodes = lower[:, None, :] + _CORNERS[None, :, :]
            factors = np.where(_CORNERS[None, :, :] == 1,
                               frac[:, None, :], 1 - frac[:, None, :])
            stencil = np.prod(factors, axis=-1)
            allowed = ((nodes < np.asarray(self.grid.shape)[None, None, :]).all(axis=2)
                       & (stencil > 0))
            keys = np.zeros(stencil.shape, dtype=np.int64)
            keys[allowed] = np.ravel_multi_index(nodes[allowed].T, self.grid.shape)
            pos = np.searchsorted(self.indices, keys)
            clipped = np.clip(pos, 0, self.active_cells - 1)
            exists = allowed & (pos < self.active_cells) & (self.indices[clipped] == keys)
            w = np.where(exists, stencil, 0)
            node_mass = np.where(exists, self.mass[clipped], 0)
            wm = w * node_mass
            denominator = wm.sum(axis=1)
            numerator = np.sum(wm[..., None] * self.values[clipped], axis=1)
            indices_out = start + np.flatnonzero(inside)
            good = denominator > 0
            result[indices_out[good]] = numerator[good] / denominator[good, None]
            coverage[indices_out] = w.sum(axis=1)
            mass_out[indices_out] = denominator
        return QueryResult5D(result, np.clip(coverage, 0, 1), mass_out, mass_out > 0)
