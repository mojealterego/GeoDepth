# SPDX-License-Identifier: Apache-2.0
"""Bounded CPU training loop for a real, but unpretrained, ten-plane 5D field."""
from __future__ import annotations

import math

import numpy as np

from .field import GridSpec5D, _positive_int


def train_kplanes5d(
    grid: GridSpec5D, coordinates: np.ndarray, values: np.ndarray,
    confidence: np.ndarray, *, feature_dim: int = 8,
    hidden_dim: int = 32, steps: int = 200, batch_size: int = 128,
    learning_rate: float = 0.01, seed: int = 0,
):
    """Train and evaluate with a fixed seeded random holdout.

    The split is IID, *not* scene-level or time-blocked validation. Reported
    validation is diagnostic only and must not be treated as generalization
    performance for other real-world scenes.
    """
    import torch
    from torch.nn import functional as F
    from .neural import KPlanes5D

    steps = _positive_int('steps', steps, 100_000)
    batch_size = _positive_int('batch_size', batch_size, 100_000)
    if isinstance(seed, bool) or not isinstance(seed, int) or not 0 <= seed < 2**32:
        raise ValueError('seed must be a uint32 integer')
    if not isinstance(learning_rate, (float, int)) or not math.isfinite(learning_rate) or not 1e-7 <= learning_rate <= 1:
        raise ValueError('learning_rate must be finite in [1e-7, 1]')
    coords = np.asarray(coordinates)
    y = np.asarray(values)
    weight = np.asarray(confidence)
    if (coords.ndim != 2 or coords.shape[1] != 5 or
        y.ndim != 2 or y.shape[0] != len(coords) or not 1 <= y.shape[1] <= 128 or
        weight.shape != (len(coords),) or len(coords) > 100_000 or
        not np.isfinite(coords).all() or not np.isfinite(y).all() or
        not np.isfinite(weight).all() or np.any(weight < 0) or np.any(weight > 1)):
        raise ValueError('Malformed or oversized 5D training data')
    # Exclude unseen or deliberately zero-weight samples from the holdout.
    keep = weight > 0
    coords, y, weight = coords[keep], y[keep], weight[keep]
    if len(coords) < 8:
        raise ValueError('At least eight nonzero-confidence samples required')
    grid._fractional_nodes(coords, require_inside=True)
    # Fixed RNG state without modifying random state of the host application.
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(seed)
        model = KPlanes5D(grid, feature_dim=feature_dim, output_dim=y.shape[1],
                          hidden_dim=hidden_dim)
    points = torch.as_tensor(coords, dtype=torch.float32, device='cpu')
    target = torch.as_tensor(y, dtype=torch.float32, device='cpu')
    weights = torch.as_tensor(weight, dtype=torch.float32, device='cpu')
    generator = torch.Generator(device='cpu').manual_seed(seed)
    permutation = torch.randperm(len(coords), generator=generator)
    n_valid = max(1, int(math.ceil(len(coords) * .2)))
    train_idx, validation_idx = permutation[n_valid:], permutation[:n_valid]
    if len(train_idx) == 0:
        raise ValueError('No training samples left after holdout')
    opt = torch.optim.Adam(model.parameters(), lr=learning_rate)

    def error_for(indices: 'torch.Tensor') -> float:
        model.eval()
        total_error = 0.0
        total_weight = 0.0
        with torch.no_grad():
            for chunk in indices.split(2048):
                out = model(points[chunk])
                per_point = ((out - target[chunk]) ** 2).mean(dim=1)
                total_error += float((per_point * weights[chunk]).sum())
                total_weight += float(weights[chunk].sum())
        return total_error / total_weight

    initial_train = error_for(train_idx)
    initial_validation = error_for(validation_idx)
    for _ in range(steps):
        model.train()
        idx = train_idx[torch.randint(len(train_idx), (min(batch_size, len(train_idx)),),
                                       generator=generator)]
        opt.zero_grad(set_to_none=True)
        out = model(points[idx])
        per_point = ((out - target[idx]) ** 2).mean(dim=1)
        loss = (per_point * weights[idx]).sum() / weights[idx].sum()
        if not bool(torch.isfinite(loss)):
            raise ValueError('Nonfinite training loss')
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0, error_if_nonfinite=True)
        opt.step()
    final_train = error_for(train_idx)
    final_valid = error_for(validation_idx)
    model.eval()
    return model, {
        'schema': 'omega.5d.training/1',
        'samples_count': int(len(coords)),
        'train_count': int(len(train_idx)),
        'validation_count': int(len(validation_idx)),
        'training_loss_initial': initial_train,
        'training_loss_final': final_train,
        'validation_loss_initial': initial_validation,
        'validation_loss_final': final_valid,
        'loss': 'confidence_weighted_MSE',
        'split': 'fixed_seed_random_80_20_IID_not_scene_independent',
        'steps': steps, 'batch_size': batch_size, 'learning_rate': float(learning_rate),
        'seed': seed, 'feature_dim': model.feature_dim,
        'hidden_dim': model.hidden_dim, 'output_dim': model.output_dim,
        'warning': 'Only provided samples were trained; no external accuracy verified',
    }
