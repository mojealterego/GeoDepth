# SPDX-License-Identifier: Apache-2.0
"""OMEGA 5D offline pipeline: metric lift, sparse fit/query and optional neural train/inference."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from representations4d.geometry import CameraIntrinsics, DepthFrame, DepthKind, RigidTransform
from . import SparseField5D, lift_metric_rgbd
from .field import _positive_float
from .io import (load_field, load_samples, read_grid, read_json, safe_load_npy,
                 safe_load_npz, save_field, save_samples, save_npz_new,
                 sha256_file)


def _metric_depth(path: Path, depth_kind: str) -> DepthFrame:
    if depth_kind != 'metric':
        raise ValueError('Only explicitly metric depth is accepted by 5D lift')
    if path.suffix.lower() == '.npy':
        return DepthFrame(safe_load_npy(path), DepthKind.METRIC)
    if path.suffix.lower() == '.npz':
        data = safe_load_npz(path)
        if 'depth_m' not in data or 'units' not in data or str(data['units']) != 'm':
            raise ValueError('Metric depth NPZ must declare depth_m and units=m')
        return DepthFrame(data['depth_m'], DepthKind.METRIC, data.get('valid'))
    raise ValueError('Depth input must be .npy or metric .npz')


def _lift(args: argparse.Namespace) -> None:
    manifest = read_json(args.manifest)
    if (not isinstance(manifest, dict) or set(manifest) != {'frames'} or
        not isinstance(manifest['frames'], list) or
        not 1 <= len(manifest['frames']) <= 1000):
        raise ValueError('Manifest must contain 1..1000 frames')
    reference = _positive_float('reference-radius-m', args.reference_radius_m)
    times: list[float] = []
    batches = []
    provenance = []
    total = 0
    feature_channels = None
    for frame_spec in manifest['frames']:
        required = {'depth', 'depth_kind', 'camera', 'pose', 'time_s'}
        allowed = required | {'features', 'confidence'}
        if not isinstance(frame_spec, dict) or not required <= set(frame_spec) or not set(frame_spec) <= allowed:
            raise ValueError('Frame requires depth/depth_kind/camera/pose/time_s and optional features/confidence')
        if any(not isinstance(frame_spec[k], str) for k in required - {'time_s'}):
            raise ValueError('Frame input paths must be strings')
        paths = {k: args.manifest.parent / frame_spec[k] for k in
                 ('depth', 'camera', 'pose', 'features', 'confidence') if k in frame_spec}
        frame = _metric_depth(paths['depth'], frame_spec['depth_kind'])
        camera = CameraIntrinsics(**read_json(paths['camera']))
        pose = RigidTransform(**read_json(paths['pose']))
        features = safe_load_npy(paths['features']) if 'features' in paths else None
        confidence = safe_load_npy(paths['confidence']) if 'confidence' in paths else None
        timestamp = frame_spec['time_s']
        if not isinstance(timestamp, (float, int)) or isinstance(timestamp, bool) or not np.isfinite(timestamp):
            raise ValueError('Frame timestamp must be finite seconds')
        timestamp = float(timestamp)
        if times and timestamp <= times[-1]:
            raise ValueError('Frame timestamps must be strictly increasing')
        times.append(timestamp)
        batch = lift_metric_rgbd(frame, camera, pose, timestamp, reference,
                                 features=features, confidence_map=confidence,
                                 stride=args.stride,
                                 max_points=args.max_points_per_frame)
        if feature_channels is not None and batch.values.shape[1] != feature_channels:
            raise ValueError('Cannot fuse frames with different feature dimensions')
        feature_channels = batch.values.shape[1]
        total += len(batch.coordinates)
        if total > args.max_samples:
            raise MemoryError(f'Too many 5D samples: {total} > {args.max_samples}')
        batches.append(batch)
        provenance.append({'time_s': timestamp, 'rows': len(batch.coordinates),
                           'sha256': {k: sha256_file(v) for k, v in paths.items()}})
    if total == 0:
        raise ValueError('No valid metric observations in sequence')
    save_samples(args.output,
                 np.concatenate([b.coordinates for b in batches]),
                 np.concatenate([b.values for b in batches]),
                 np.concatenate([b.confidence for b in batches]),
                 reference_radius_m=reference,
                 provenance={'frame_count': len(batches),
                             'manifest_sha256': sha256_file(args.manifest),
                             'frame_sources': provenance,
                             'depth_kind': 'user_declared_metric_not_verified',
                             'scale_definition': 'z_cam/sqrt(fx*fy) at each selected pixel',
                             'pose_convention': 'world_from_camera (SE3)'})


def _fit(args: argparse.Namespace) -> None:
    coords, values, confidence, reference, _ = load_samples(args.samples)
    grid = read_grid(args.grid)
    if reference != grid.reference_radius_m:
        raise ValueError('Sample/grid reference_radius_m mismatch; cannot mix scale coordinates')
    field = SparseField5D.fit(grid, coords, values, confidence,
                              max_samples=args.max_samples,
                              max_active_cells=args.max_active_cells)
    save_field(args.output, field,
               {'samples_sha256': sha256_file(args.samples),
                'grid_sha256': sha256_file(args.grid),
                'observations': len(coords), 'active_cells': field.active_cells,
                'limitations': 'Weighted sparse interpolation, no learned 5D model'})


def _query(args: argparse.Namespace) -> None:
    field, _ = load_field(args.field)
    points = safe_load_npy(args.points)
    result = field.query(points)
    md = {'schema': 'omega.5d.query/1', 'field_sha256': sha256_file(args.field),
          'query_sha256': sha256_file(args.points),
          'definition': 'coverage is supported stencil weight; mass is accumulated confidence',
          'extrapolation': 'none; unknown values are NaN'}
    save_npz_new(args.output, values=result.values, coverage=result.coverage,
                 mass=result.mass, supported=result.supported,
                 metadata=np.array(json.dumps(md, sort_keys=True)))


def _train(args: argparse.Namespace) -> None:
    # Import lazily so all NumPy geometry commands work without PyTorch.
    from .train import train_kplanes5d
    from .neural import save_kplanes5d

    coords, values, confidence, reference, _ = load_samples(args.samples)
    grid = read_grid(args.grid)
    if reference != grid.reference_radius_m:
        raise ValueError('Sample/grid reference_radius_m mismatch')
    model, metrics = train_kplanes5d(
        grid, coords, values, confidence,
        feature_dim=args.feature_dim, hidden_dim=args.hidden_dim,
        steps=args.steps, batch_size=args.batch_size,
        learning_rate=args.learning_rate, seed=args.seed,
    )
    metrics['samples_sha256'] = sha256_file(args.samples)
    metrics['grid_sha256'] = sha256_file(args.grid)
    save_kplanes5d(args.output, model, metrics)
    print(json.dumps(metrics, sort_keys=True))


def _neural_query(args: argparse.Namespace) -> None:
    import torch
    from .neural import load_kplanes5d

    model, _ = load_kplanes5d(args.checkpoint)
    points = safe_load_npy(args.points)
    if points.ndim != 2 or points.shape[1] != 5 or not np.isfinite(points).all():
        raise ValueError('Neural query points must be finite [N,5]')
    if len(points) > 100_000:
        raise MemoryError('At most 100000 query points allowed')
    parts = []
    with torch.no_grad():
        for start in range(0, len(points), 2048):
            part = model(torch.as_tensor(points[start:start + 2048], dtype=torch.float32))
            parts.append(part.cpu().numpy())
    out = np.concatenate(parts, axis=0) if parts else np.empty((0, model.output_dim))
    metadata = {'schema': 'omega.5d.neural-query/1',
                'checkpoint_sha256': sha256_file(args.checkpoint),
                'points_sha256': sha256_file(args.points),
                'warning': 'Predictions are learned estimates, not measurements'}
    save_npz_new(args.output, values=out,
                 metadata=np.array(json.dumps(metadata, sort_keys=True)))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    lift = sub.add_parser('lift', help='Convert calibrated metric RGB-D sequence to sparse observations')
    lift.add_argument('--manifest', type=Path, required=True)
    lift.add_argument('--reference-radius-m', type=float, required=True)
    lift.add_argument('--output', type=Path, required=True)
    lift.add_argument('--stride', type=int, default=1)
    lift.add_argument('--max-points-per-frame', type=int, default=100_000)
    lift.add_argument('--max-samples', type=int, default=100_000)
    fit = sub.add_parser('fit', help='Confidence-weighted sparse 5D gridding')
    fit.add_argument('--samples', type=Path, required=True)
    fit.add_argument('--grid', type=Path, required=True)
    fit.add_argument('--output', type=Path, required=True)
    fit.add_argument('--max-samples', type=int, default=100_000)
    fit.add_argument('--max-active-cells', type=int, default=250_000)
    query = sub.add_parser('query', help='32-corner interpolation at [N,5] query points')
    query.add_argument('--field', type=Path, required=True)
    query.add_argument('--points', type=Path, required=True)
    query.add_argument('--output', type=Path, required=True)
    train = sub.add_parser('train', help='Learn a real 10-plane PyTorch 5D model from 5D samples')
    train.add_argument('--samples', type=Path, required=True)
    train.add_argument('--grid', type=Path, required=True)
    train.add_argument('--output', type=Path, required=True,
                       help='New .safetensors checkpoint (will not overwrite)')
    train.add_argument('--feature-dim', type=int, default=8)
    train.add_argument('--hidden-dim', type=int, default=32)
    train.add_argument('--steps', type=int, default=200)
    train.add_argument('--batch-size', type=int, default=128)
    train.add_argument('--learning-rate', type=float, default=.01)
    train.add_argument('--seed', type=int, default=0)
    predict = sub.add_parser('neural-query', help='Query a trained KPlanes5D safetensors checkpoint')
    predict.add_argument('--checkpoint', type=Path, required=True)
    predict.add_argument('--points', type=Path, required=True)
    predict.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == 'lift':
            _lift(args)
        elif args.command == 'fit':
            _fit(args)
        elif args.command == 'query':
            _query(args)
        elif args.command == 'train':
            _train(args)
        else:
            _neural_query(args)
    except (ValueError, TypeError, FileNotFoundError, OSError, MemoryError,
            OverflowError, KeyError, IndexError, ImportError, RuntimeError, json.JSONDecodeError) as error:
        parser.error(str(error))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
