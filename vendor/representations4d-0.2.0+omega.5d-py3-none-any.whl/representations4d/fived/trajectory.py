# SPDX-License-Identifier: Apache-2.0
"""Continuous, explicitly non-extrapolating scale-aware 3D trajectories."""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np

from .field import _positive_float


@dataclass(frozen=True)
class Trajectory5D:
    time_seconds: np.ndarray
    positions_m: np.ndarray
    footprint_m: np.ndarray
    reference_radius_m: float

    def __post_init__(self) -> None:
        times = np.asarray(self.time_seconds)
        xyz = np.asarray(self.positions_m)
        radius = np.asarray(self.footprint_m)
        if (times.ndim != 1 or len(times) < 2 or times.dtype.kind not in 'fiu' or
            xyz.shape != (len(times), 3) or xyz.dtype.kind not in 'fiu' or
            radius.shape != times.shape or radius.dtype.kind not in 'fiu'):
            raise ValueError('Trajectory needs times [N], positions [N,3], radii [N], N>=2')
        times = times.astype(np.float64, copy=True)
        xyz = xyz.astype(np.float64, copy=True)
        radius = radius.astype(np.float64, copy=True)
        if (not np.isfinite(times).all() or not np.isfinite(xyz).all() or
            not np.isfinite(radius).all() or np.any(radius <= 0) or
            np.any(np.diff(times) <= 0)):
            raise ValueError('Trajectory times must be strictly increasing, coordinates finite, radii positive')
        for val in (times, xyz, radius):
            val.setflags(write=False)
        object.__setattr__(self, 'time_seconds', times)
        object.__setattr__(self, 'positions_m', xyz)
        object.__setattr__(self, 'footprint_m', radius)
        object.__setattr__(self, 'reference_radius_m',
                           _positive_float('reference_radius_m', self.reference_radius_m))

    def sample(self, query_time_seconds: np.ndarray) -> np.ndarray:
        q = np.asarray(query_time_seconds)
        if q.ndim != 1 or q.dtype.kind not in 'fiu' or not np.isfinite(q).all():
            raise ValueError('Query timestamps must be finite [M]')
        t = q.astype(np.float64)
        if np.any(t < self.time_seconds[0]) or np.any(t > self.time_seconds[-1]):
            raise ValueError('Trajectory extrapolation is prohibited')
        pos = np.searchsorted(self.time_seconds, t, side='right')
        r = np.clip(pos, 1, len(self.time_seconds) - 1)
        l = r - 1
        fraction = ((t - self.time_seconds[l]) /
                    (self.time_seconds[r] - self.time_seconds[l]))
        xyz = self.positions_m[l] * (1 - fraction[:, None]) + self.positions_m[r] * fraction[:, None]
        log_radii = np.log2(self.footprint_m / self.reference_radius_m)
        scale = log_radii[l] * (1 - fraction) + log_radii[r] * fraction
        return np.column_stack((xyz, t, scale))
