# SPDX-License-Identifier: Apache-2.0
"""Differentiable factorized 5D field with ten learnable pairwise planes.

Architecture *inspired by* K-Planes (CVPR 2023); this is an independent
compact PyTorch implementation, not a port of their trained weights.
Requires optional torch. No real-scene accuracy claims are implied.
"""
from __future__ import annotations

from dataclasses import asdict
from itertools import combinations
import json
import os
from pathlib import Path
import tempfile

import torch
from torch import nn
from torch.nn import functional as F

from .field import Axis5D, GridSpec5D, _positive_int
from .io import MAX_FILE_BYTES


class KPlanes5D(nn.Module):
    """Ten dense 2D feature planes with a small shared nonlinear decoder.

    Input [N,5] is always X/Y/Z meters, seconds, log2 footprint ratio.
    Pairwise features are sampled with differentiable bilinear interpolation.
    The full 5D dense tensor is never materialized.
    """
    def __init__(self, grid: GridSpec5D, *, feature_dim: int = 8,
                 output_dim: int = 1, hidden_dim: int = 64):
        super().__init__()
        if not isinstance(grid, GridSpec5D):
            raise ValueError('GridSpec5D required')
        feature_dim = _positive_int('feature_dim', feature_dim, 128)
        output_dim = _positive_int('output_dim', output_dim, 128)
        hidden_dim = _positive_int('hidden_dim', hidden_dim, 512)
        shape = grid.shape
        pairs = tuple(combinations(range(5), 2))
        if feature_dim * sum(shape[i] * shape[j] for i, j in pairs) > 2_000_000:
            raise MemoryError('Too many 5D pairwise feature parameters (limit 2000000)')
        self.grid = grid
        self.feature_dim = feature_dim
        self.output_dim = output_dim
        self.hidden_dim = hidden_dim
        self.pairs = pairs
        self.planes = nn.ParameterList([
            nn.Parameter(torch.randn(1, feature_dim, shape[i], shape[j]) * .02)
            for i, j in pairs
        ])
        self.decoder = nn.Sequential(
            nn.Linear(10 * feature_dim + 5, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
        )
        self.register_buffer('_origins', torch.tensor([a.origin for a in grid.axes], dtype=torch.float32))
        self.register_buffer('_spans', torch.tensor([a.step * (a.count-1) for a in grid.axes], dtype=torch.float32))

    def forward(self, coordinates: torch.Tensor) -> torch.Tensor:
        if not isinstance(coordinates, torch.Tensor) or coordinates.ndim != 2 or coordinates.shape[1] != 5:
            raise ValueError('Neural field expects torch.Tensor [N,5]')
        if not torch.is_floating_point(coordinates) or not bool(torch.isfinite(coordinates).all()):
            raise ValueError('Neural coordinates must be finite floating points')
        if len(coordinates) > 100_000:
            raise MemoryError('At most 100000 neural queries per forward pass')
        coords = coordinates.to(dtype=self._origins.dtype, device=self._origins.device)
        normalized = 2 * (coords - self._origins) / self._spans - 1
        if not bool(torch.isfinite(normalized).all()):
            raise ValueError('Neural coordinate normalization overflow')
        if bool((normalized.abs() > 1.000001).any()):
            raise ValueError('Neural query outside declared 5D grid')
        if len(coords) == 0:
            return coords.new_empty((0, self.output_dim))
        factors: list[torch.Tensor] = []
        for (i, j), plane in zip(self.pairs, self.planes, strict=True):
            # grid_sample expects (x=j, y=i) for image (H=i, W=j).
            sample_grid = torch.stack((normalized[:, j], normalized[:, i]), dim=-1)
            sample_grid = sample_grid.view(1, -1, 1, 2)
            sampled = F.grid_sample(plane, sample_grid, mode='bilinear',
                                    padding_mode='border', align_corners=True)
            factors.append(sampled.squeeze(0).squeeze(-1).T)
        return self.decoder(torch.cat((*factors, normalized), dim=1))


def _model_config(model: KPlanes5D) -> dict:
    return {'axes': [asdict(a) for a in model.grid.axes],
            'reference_radius_m': model.grid.reference_radius_m,
            'feature_dim': model.feature_dim,
            'output_dim': model.output_dim,
            'hidden_dim': model.hidden_dim}


def save_kplanes5d(path: Path, model: KPlanes5D, metadata: dict | None = None) -> None:
    """Atomically save non-pickle tensor checkpoint; refuses overwrites."""
    from safetensors.torch import save_file
    path = Path(path)
    if path.suffix != '.safetensors' or not path.parent.is_dir():
        raise ValueError('Output must be .safetensors in an existing directory')
    if not isinstance(model, KPlanes5D):
        raise ValueError('Expected KPlanes5D model')
    details = metadata or {}
    config = json.dumps(_model_config(model), sort_keys=True)
    md = json.dumps(details, sort_keys=True)
    if len(config) + len(md) > 128_000:
        raise ValueError('Checkpoint metadata too long')
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.omega5d-',
                                         suffix='.safetensors', delete=False) as f:
            temp_path = Path(f.name)
        tensors = {name: value.detach().cpu().contiguous()
                   for name, value in model.state_dict().items()}
        save_file(tensors, str(temp_path), metadata={
            'schema': 'omega.5d.kplanes/1', 'model_config': config, 'provenance': md,
        })
        with temp_path.open('rb') as f:
            os.fsync(f.fileno())
        os.link(temp_path, path)
        fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def load_kplanes5d(path: Path) -> tuple[KPlanes5D, dict]:
    """Strict shape/key checking, CPU only. Never unpickles tensors."""
    from safetensors import safe_open
    from safetensors.torch import load_file
    path = Path(path)
    if path.suffix != '.safetensors' or not path.is_file() or path.stat().st_size > MAX_FILE_BYTES:
        raise ValueError('Expected bounded .safetensors checkpoint')
    with safe_open(str(path), framework='pt', device='cpu') as opened:
        md = opened.metadata() or {}
    if md.get('schema') != 'omega.5d.kplanes/1':
        raise ValueError('Wrong KPlanes5D checkpoint schema')
    if len(md.get('model_config', '')) + len(md.get('provenance', '')) > 128_000:
        raise ValueError('Unreasonably large model metadata')
    config = json.loads(md['model_config'])
    expected = {'axes', 'reference_radius_m', 'feature_dim', 'output_dim', 'hidden_dim'}
    if not isinstance(config, dict) or set(config) != expected:
        raise ValueError('Invalid model configuration')
    axes = config['axes']
    if not isinstance(axes, list) or len(axes) != 5:
        raise ValueError('Invalid model axes')
    grid = GridSpec5D(tuple(Axis5D(**axis) for axis in axes), config['reference_radius_m'])
    model = KPlanes5D(grid, feature_dim=config['feature_dim'],
                      output_dim=config['output_dim'], hidden_dim=config['hidden_dim'])
    state = load_file(str(path), device='cpu')
    model.load_state_dict(state, strict=True)
    model.eval()
    provenance = json.loads(md.get('provenance', '{}'))
    if not isinstance(provenance, dict):
        raise ValueError('Provenance must be a JSON object')
    return model, provenance
