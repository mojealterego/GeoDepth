# SPDX-License-Identifier: Apache-2.0
"""Explicit NPZ v1 schemas, size preflight, immutable field validation and atomic writes."""
from __future__ import annotations

from dataclasses import asdict
import json
import os
from pathlib import Path
import tempfile
import zipfile

import numpy as np

from .field import Axis5D, GridSpec5D, SparseField5D, _positive_float, _matrix

MAX_FILE_BYTES = 256 * 1024 * 1024
MAX_EXPANDED_BYTES = 256 * 1024 * 1024
MAX_METADATA_BYTES = 128 * 1024


def sha256_file(path: Path) -> str:
    import hashlib
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _preflight(path: Path, max_bytes: int = MAX_FILE_BYTES) -> None:
    if not Path(path).is_file():
        raise FileNotFoundError(str(path))
    if Path(path).stat().st_size > max_bytes:
        raise ValueError(f'Input file exceeds {max_bytes} bytes')


def safe_load_npy(path: Path) -> np.ndarray:
    path = Path(path)
    if path.suffix.lower() != '.npy':
        raise ValueError('Input must be a .npy file')
    _preflight(path)
    loaded = np.load(path, allow_pickle=False, max_header_size=10_000)
    if not isinstance(loaded, np.ndarray):
        raise ValueError('NPY array required')
    if loaded.nbytes > MAX_EXPANDED_BYTES:
        raise ValueError('Array exceeds memory limit')
    return loaded


def safe_load_npz(path: Path, *, max_uncompressed_bytes: int = MAX_EXPANDED_BYTES) -> dict[str, np.ndarray]:
    path = Path(path)
    if path.suffix.lower() != '.npz':
        raise ValueError('Input must be a .npz file')
    _preflight(path)
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        if (len(entries) > 20 or
            sum(info.file_size for info in entries) > max_uncompressed_bytes or
            any(info.file_size > max_uncompressed_bytes or not info.filename.endswith('.npy')
                or Path(info.filename).name != info.filename for info in entries) or
            len({info.filename for info in entries}) != len(entries)):
            raise ValueError('NPZ exceeds declared resource limits or has unsafe members')
    with np.load(path, allow_pickle=False, max_header_size=10_000) as arrays:
        result = {name: np.array(arrays[name], copy=True) for name in arrays.files}
    if sum(a.nbytes for a in result.values()) > max_uncompressed_bytes:
        raise ValueError('Decoded arrays exceed resource limit')
    return result


def _string_scalar(value: np.ndarray, name: str) -> str:
    arr = np.asarray(value)
    if arr.ndim != 0 or arr.dtype.kind != 'U':
        raise ValueError(f'{name} must be a Unicode scalar')
    result = str(arr.item())
    if len(result.encode('utf-8')) > MAX_METADATA_BYTES:
        raise ValueError(f'{name} too large')
    return result


def _metadata(value: np.ndarray, schema: str) -> dict:
    parsed = json.loads(_string_scalar(value, 'metadata'))
    if not isinstance(parsed, dict) or parsed.get('schema') != schema:
        raise ValueError(f'Expected schema {schema}')
    return parsed


def _require_keys(data: dict, expected: set[str]):
    if set(data) != expected:
        raise ValueError(f'Expected array keys {sorted(expected)}, received {sorted(data)}')


def _grid_json(grid: GridSpec5D) -> dict:
    return {'axes': [asdict(a) for a in grid.axes],
            'reference_radius_m': grid.reference_radius_m}


def _from_grid_json(payload: dict) -> GridSpec5D:
    if not isinstance(payload, dict) or set(payload) != {'axes', 'reference_radius_m'}:
        raise ValueError('Grid JSON requires only axes and reference_radius_m')
    axes = payload['axes']
    if not isinstance(axes, list) or len(axes) != 5:
        raise ValueError('Grid JSON requires five axes')
    if any(not isinstance(a, dict) or set(a) != {'origin', 'step', 'count'} for a in axes):
        raise ValueError('Each axis must contain origin, step, count')
    return GridSpec5D(tuple(Axis5D(**a) for a in axes), payload['reference_radius_m'])


def read_grid(path: Path) -> GridSpec5D:
    _preflight(path, max_bytes=MAX_METADATA_BYTES)
    with Path(path).open('r', encoding='utf-8') as f:
        return _from_grid_json(json.load(f))


def read_json(path: Path):
    _preflight(path, max_bytes=MAX_METADATA_BYTES)
    with Path(path).open('r', encoding='utf-8') as f:
        return json.load(f)


def save_npz_new(path: Path, **arrays: np.ndarray) -> None:
    """Publish new output atomically; preserve existing paths without overwrite."""
    path = Path(path)
    if path.suffix.lower() != '.npz' or not path.parent.is_dir():
        raise ValueError('Destination must be .npz in an existing directory')
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.omega5d-',
                                         suffix='.npz', delete=False) as temp:
            temp_path = Path(temp.name)
            np.savez_compressed(temp, **arrays)
            temp.flush()
            os.fsync(temp.fileno())
        # No replace or clobber: atomic creation fails when output exists.
        os.link(temp_path, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def save_samples(path: Path, coordinates: np.ndarray, values: np.ndarray,
                 confidence: np.ndarray, *, reference_radius_m: float,
                 provenance: dict) -> None:
    coords = _matrix('coordinates', coordinates, 5)
    vals = np.asarray(values)
    weights = np.asarray(confidence)
    if (vals.ndim != 2 or vals.shape[0] != len(coords) or
        not (1 <= vals.shape[1] <= 256) or vals.dtype.kind not in 'fiu' or
        not np.isfinite(vals).all() or weights.shape != (len(coords),) or
        weights.dtype.kind not in 'fiu' or not np.isfinite(weights).all() or
        np.any(weights < 0) or np.any(weights > 1)):
        raise ValueError('Sample values [N,C] / confidence [N] malformed')
    ref = _positive_float('reference_radius_m', reference_radius_m)
    md = {'schema': 'omega.5d.samples/1', 'units': ['m','m','m','s','log2(radius_m/reference_m)'],
          'reference_radius_m': ref, 'provenance': provenance}
    save_npz_new(path, coordinates=coords, values=np.asarray(vals, dtype=np.float64),
                 confidence=np.asarray(weights, dtype=np.float64),
                 metadata=np.array(json.dumps(md, sort_keys=True)))


def load_samples(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, float, dict]:
    data = safe_load_npz(path)
    _require_keys(data, {'coordinates', 'values', 'confidence', 'metadata'})
    md = _metadata(data['metadata'], 'omega.5d.samples/1')
    if md.get('units') != ['m','m','m','s','log2(radius_m/reference_m)']:
        raise ValueError('Sample coordinate units not recognized')
    ref = _positive_float('reference_radius_m', md.get('reference_radius_m'))
    coords = _matrix('coordinates', data['coordinates'], 5)
    values = data['values']
    confidence = data['confidence']
    if (values.ndim != 2 or values.shape[0] != len(coords) or
        not 1 <= values.shape[1] <= 256 or values.dtype.kind not in 'fiu' or
        not np.isfinite(values).all() or confidence.shape != (len(coords),) or
        confidence.dtype.kind not in 'fiu' or not np.isfinite(confidence).all() or
        np.any(confidence < 0) or np.any(confidence > 1)):
        raise ValueError('Invalid sample feature/confidence arrays')
    return coords, values, confidence, ref, md


def save_field(path: Path, field: SparseField5D, provenance: dict) -> None:
    md = {'schema': 'omega.5d.field/1',
          'units': ['m','m','m','s','log2(radius_m/reference_m)'],
          **provenance}
    # Do not let provenance override schema, units, or formal grid.
    md['schema'] = 'omega.5d.field/1'
    md['units'] = ['m','m','m','s','log2(radius_m/reference_m)']
    save_npz_new(path, indices=field.indices, values=field.values, mass=field.mass,
                 grid=np.array(json.dumps(_grid_json(field.grid), sort_keys=True)),
                 metadata=np.array(json.dumps(md, sort_keys=True)))


def load_field(path: Path) -> tuple[SparseField5D, dict]:
    data = safe_load_npz(path)
    _require_keys(data, {'indices', 'values', 'mass', 'grid', 'metadata'})
    metadata = _metadata(data['metadata'], 'omega.5d.field/1')
    if metadata.get('units') != ['m','m','m','s','log2(radius_m/reference_m)']:
        raise ValueError('Unexpected field unit schema')
    grid = _from_grid_json(json.loads(_string_scalar(data['grid'], 'grid')))
    return SparseField5D(grid, data['indices'], data['values'], data['mass']), metadata
