"""Deterministic SE(3) temporal depth reprojection with visibility checks.

No optical-flow or motion segmentation is inferred. The caller must supply
accurate camera calibration and camera-to-camera pose; moving objects may
cause residuals even when the depth estimator is correct.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .core import (CameraIntrinsics, DepthFrame, DepthKind,
                   RigidTransform, backproject, project)


@dataclass(frozen=True)
class ReprojectionResult:
    depth: DepthFrame
    coverage: float
    source_points: int
    visible_pixels: int


@dataclass(frozen=True)
class TemporalConsistencyResult:
    absolute_error: np.ndarray
    relative_error: np.ndarray
    valid: np.ndarray
    coverage: float


def reproject_depth(
    source: DepthFrame,
    source_camera: CameraIntrinsics,
    destination_camera: CameraIntrinsics,
    source_to_destination: RigidTransform,
) -> ReprojectionResult:
    """Project source metric depth into destination camera with a Z-buffer.

    Nearest-neighbor pixel splatting is intentionally conservative: holes
    remain NaN. A true metric pose and metric depth are mandatory.
    """
    if source.kind is not DepthKind.METRIC:
        raise ValueError('Temporal reprojection requires metric depth')
    cloud = backproject(source, source_camera)
    transformed = source_to_destination.apply(cloud.xyz)
    uv, z, visible = project(transformed, destination_camera)
    h, w = destination_camera.height, destination_camera.width
    depth_flat = np.full(h * w, np.nan, dtype=np.float64)
    if np.any(visible):
        src_ids = np.flatnonzero(visible)
        coords = np.rint(uv[visible]).astype(np.int64)
        # The visibility check is continuous; roundoff cannot produce valid
        # indices outside the image, but retain a defensive integer check.
        in_bounds = ((coords[:, 0] >= 0) & (coords[:, 0] < w) &
                     (coords[:, 1] >= 0) & (coords[:, 1] < h))
        coords = coords[in_bounds]
        src_ids = src_ids[in_bounds]
        pixels = coords[:, 1] * w + coords[:, 0]
        order = np.lexsort((src_ids, z[src_ids]))  # nearest first
        unique_pixels, first = np.unique(pixels[order], return_index=True)
        depth_flat[unique_pixels] = z[src_ids[order[first]]]
    depth = DepthFrame(depth_flat.reshape(h, w), DepthKind.METRIC)
    count = int(depth.mask.sum())
    return ReprojectionResult(depth, count / (h * w), len(cloud.xyz), count)


def temporal_depth_consistency(
    previous: DepthFrame,
    current: DepthFrame,
    previous_camera: CameraIntrinsics,
    current_camera: CameraIntrinsics,
    previous_to_current: RigidTransform,
) -> TemporalConsistencyResult:
    """Compare reprojected previous depth against observed current depth.

    This returns geometric residuals, NOT calibrated confidence scores or
    learned uncertainty. Dynamic objects and occlusion can produce outliers.
    """
    if current.kind is not DepthKind.METRIC:
        raise ValueError('Temporal consistency requires metric depth')
    warped = reproject_depth(previous, previous_camera, current_camera,
                             previous_to_current)
    if current.values.shape != warped.depth.values.shape:
        raise ValueError('Current depth resolution differs from destination camera')
    valid = warped.depth.mask & current.mask
    abs_error = np.full(current.values.shape, np.nan, dtype=np.float64)
    rel_error = np.full(current.values.shape, np.nan, dtype=np.float64)
    abs_error[valid] = np.abs(warped.depth.values[valid] - current.values[valid])
    rel_error[valid] = abs_error[valid] / current.values[valid]
    return TemporalConsistencyResult(abs_error, rel_error, valid,
                                     float(np.mean(valid)))
