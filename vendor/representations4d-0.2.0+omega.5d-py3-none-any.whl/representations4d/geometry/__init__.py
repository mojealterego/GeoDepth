# SPDX-License-Identifier: Apache-2.0
"""NumPy-only, physically explicit camera geometry for 4D representations.

This module does not estimate depth or uncertainty. Its outputs retain the
provenance of supplied depth values and distinguish metric from relative units.
"""
from .core import (CameraIntrinsics, DepthFrame, DepthKind, PointCloud,
                   RigidTransform, ScaleCalibrationReport, backproject,
                   calibrate_relative_depth, estimate_normals, project)
from .temporal import (ReprojectionResult, TemporalConsistencyResult,
                       reproject_depth, temporal_depth_consistency)

__all__ = [
    'CameraIntrinsics', 'DepthFrame', 'DepthKind', 'PointCloud',
    'RigidTransform', 'ScaleCalibrationReport', 'backproject',
    'calibrate_relative_depth', 'estimate_normals', 'project',
    'ReprojectionResult', 'TemporalConsistencyResult',
    'reproject_depth', 'temporal_depth_consistency',
]
