"""Unit-aware pinhole geometry, normal estimation and scale calibration.

Coordinate convention: camera X right, Y down, Z forward. Pixel coordinates
refer to pixel centers at integer u/v positions. No lens distortion is modeled.
A relative depth field is NOT a metric measurement; calibration is explicit.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Sequence

import numpy as np


class DepthKind(str, Enum):
    """Physical interpretation of supplied depth values."""

    RELATIVE = 'relative'
    METRIC = 'metric'


@dataclass(frozen=True)
class CameraIntrinsics:
    """Calibrated pinhole intrinsics in pixels, for one image resolution."""

    width: int
    height: int
    fx: float
    fy: float
    cx: float
    cy: float

    def __post_init__(self) -> None:
        if isinstance(self.width, bool) or isinstance(self.height, bool) or (
            not isinstance(self.width, (int, np.integer)) or
            not isinstance(self.height, (int, np.integer)) or
            self.width <= 0 or self.height <= 0
        ):
            raise ValueError('Camera width and height must be positive integers')
        if not all(np.isfinite(x) for x in (self.fx, self.fy, self.cx, self.cy)):
            raise ValueError('Camera intrinsics must be finite')
        if self.fx <= 0 or self.fy <= 0:
            raise ValueError('Focal lengths fx and fy must be positive')


@dataclass(frozen=True)
class DepthFrame:
    """Depth field with explicit units and validity, without fabricated values."""

    values: np.ndarray
    kind: DepthKind
    mask: np.ndarray | None = None

    def __post_init__(self) -> None:
        arr = np.asarray(self.values)
        if arr.ndim != 2 or not all(x > 0 for x in arr.shape):
            raise ValueError('Depth values must have nonempty [H, W] shape')
        if arr.dtype.kind not in 'fiu':
            raise TypeError('Depth values must be real numeric values')
        if not isinstance(self.kind, DepthKind):
            raise ValueError('Depth kind must be DepthKind.RELATIVE or METRIC')
        arr = arr.astype(np.float64, copy=True)
        valid = np.isfinite(arr) & (arr > 0)
        if self.mask is not None:
            mask = np.asarray(self.mask)
            if mask.shape != arr.shape or mask.dtype != np.bool_:
                raise ValueError('Depth mask must be boolean [H, W]')
            valid &= mask
        arr.setflags(write=False)
        valid.setflags(write=False)
        object.__setattr__(self, 'values', arr)
        object.__setattr__(self, 'mask', valid)


@dataclass(frozen=True)
class PointCloud:
    """Point coordinates and their source pixel locations (u, v)."""

    xyz: np.ndarray
    uv: np.ndarray
    units: str


@dataclass(frozen=True)
class ScaleCalibrationReport:
    """Diagnostics for a scale-only assumption; not an accuracy certificate."""

    scale: float
    anchors_used: int
    max_relative_error: float


@dataclass(frozen=True)
class RigidTransform:
    """SE(3) rigid transform: p_out = R @ p_in + t."""

    rotation: np.ndarray
    translation: np.ndarray

    def __post_init__(self) -> None:
        r = np.asarray(self.rotation, dtype=np.float64)
        t = np.asarray(self.translation, dtype=np.float64)
        if r.shape != (3, 3) or t.shape != (3,):
            raise ValueError('Rigid transform needs rotation [3,3], translation [3]')
        if not np.isfinite(r).all() or not np.isfinite(t).all():
            raise ValueError('Rigid transform values must be finite')
        if not np.allclose(r.T @ r, np.eye(3), atol=1e-6, rtol=0) or not np.isclose(
            np.linalg.det(r), 1, atol=1e-6, rtol=0
        ):
            raise ValueError('Rotation must be orthonormal with determinant +1')
        r = r.copy()
        t = t.copy()
        r.setflags(write=False)
        t.setflags(write=False)
        object.__setattr__(self, 'rotation', r)
        object.__setattr__(self, 'translation', t)

    def apply(self, points: np.ndarray) -> np.ndarray:
        p = np.asarray(points, dtype=np.float64)
        if p.ndim != 2 or p.shape[1] != 3 or not np.isfinite(p).all():
            raise ValueError('Points must be finite [N,3]')
        return p @ self.rotation.T + self.translation

    def inverse(self) -> RigidTransform:
        r_inv = self.rotation.T
        return RigidTransform(r_inv, -(r_inv @ self.translation))


def _check_camera(frame: DepthFrame, camera: CameraIntrinsics) -> None:
    if frame.values.shape != (camera.height, camera.width):
        raise ValueError('Depth resolution must match camera intrinsics')


def backproject(
    frame: DepthFrame,
    camera: CameraIntrinsics,
    *,
    stride: int = 1,
    max_points: int | None = None,
    allow_relative: bool = False,
) -> PointCloud:
    """Backproject valid depth to camera XYZ, with deterministic subsampling.

    Relative depth can be backprojected only with explicit opt-in; such XYZ
    values are *not* in meters and cannot be used as metric geometry.
    """
    _check_camera(frame, camera)
    if frame.kind is DepthKind.RELATIVE and not allow_relative:
        raise ValueError('Cannot claim metric 3D from relative depth; calibrate first')
    if isinstance(stride, bool) or not isinstance(stride, (int, np.integer)) or stride < 1:
        raise ValueError('stride must be a positive integer')
    if max_points is not None and (
        isinstance(max_points, bool) or not isinstance(max_points, (int, np.integer)) or max_points < 1
    ):
        raise ValueError('max_points must be a positive integer')

    yy, xx = np.mgrid[0:camera.height:stride, 0:camera.width:stride]
    sampled_depth = frame.values[::stride, ::stride]
    valid = frame.mask[::stride, ::stride]
    u = xx[valid].astype(np.float64)
    v = yy[valid].astype(np.float64)
    z = sampled_depth[valid]
    if max_points is not None and z.size > max_points:
        # Stable, uniformly spaced subset in raster order (no random seed).
        selected = np.arange(max_points, dtype=np.int64) * z.size // max_points
        u, v, z = u[selected], v[selected], z[selected]
    xyz = np.column_stack(((u - camera.cx) * z / camera.fx,
                           (v - camera.cy) * z / camera.fy, z))
    return PointCloud(xyz=xyz, uv=np.column_stack((u, v)),
                      units='m' if frame.kind is DepthKind.METRIC else 'relative')


def project(
    points: np.ndarray,
    camera: CameraIntrinsics,
    *,
    world_to_camera: RigidTransform | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Project XYZ to pixel centers; return (uv, z, in_image_valid_mask)."""
    xyz = np.asarray(points, dtype=np.float64)
    if xyz.ndim != 2 or xyz.shape[1] != 3 or not np.isfinite(xyz).all():
        raise ValueError('Points must be finite [N,3]')
    if world_to_camera is not None:
        xyz = world_to_camera.apply(xyz)
    z = xyz[:, 2]
    front = z > 0
    uv = np.full((len(xyz), 2), np.nan, dtype=np.float64)
    uv[front, 0] = camera.fx * xyz[front, 0] / z[front] + camera.cx
    uv[front, 1] = camera.fy * xyz[front, 1] / z[front] + camera.cy
    visible = (front & (uv[:, 0] >= 0) & (uv[:, 0] <= camera.width - 1) &
               (uv[:, 1] >= 0) & (uv[:, 1] <= camera.height - 1))
    return uv, z.copy(), visible


def estimate_normals(
    frame: DepthFrame,
    camera: CameraIntrinsics,
    *,
    toward_camera: bool = True,
) -> tuple[np.ndarray, np.ndarray]:
    """Estimate local normals via central differences in 3D camera space.

    Invalid pixels and the one-pixel image boundary return NaN, not an
    invented normal. This is local geometry, not a trained normal predictor.
    """
    _check_camera(frame, camera)
    h, w = frame.values.shape
    normals = np.full((h, w, 3), np.nan, dtype=np.float64)
    valid = np.zeros((h, w), dtype=bool)
    if h < 3 or w < 3:
        return normals, valid
    yy, xx = np.indices((h, w))
    z = frame.values
    p = np.stack(((xx - camera.cx) * z / camera.fx,
                  (yy - camera.cy) * z / camera.fy, z), axis=-1)
    dx = p[1:-1, 2:] - p[1:-1, :-2]
    dy = p[2:, 1:-1] - p[:-2, 1:-1]
    n = np.cross(dx, dy)
    length = np.linalg.norm(n, axis=-1)
    good = (frame.mask[1:-1, 1:-1] & frame.mask[1:-1, :-2] &
            frame.mask[1:-1, 2:] & frame.mask[:-2, 1:-1] &
            frame.mask[2:, 1:-1] & np.isfinite(length) & (length > 1e-12))
    interior = normals[1:-1, 1:-1]
    interior[good] = n[good] / length[good, None]
    if toward_camera:
        # Orient normals to point toward the camera origin for visible surfaces.
        facing = np.sum(interior[good] * p[1:-1, 1:-1][good], axis=-1) > 0
        interior[good] *= np.where(facing[:, None], -1.0, 1.0)
    valid[1:-1, 1:-1] = good
    return normals, valid


def calibrate_relative_depth(
    frame: DepthFrame,
    pixel_anchors: Sequence[tuple[int, int]],
    reference_meters: Sequence[float],
    *,
    max_relative_error: float = 0.10,
) -> tuple[DepthFrame, ScaleCalibrationReport]:
    """Scale relative depth using >=2 independent metric depth anchors.

    Assumes d_metric = scale * d_relative. Refuses inconsistent anchors.
    This does NOT validate the relative-depth model or guarantee metric accuracy
    between anchors; it merely tests the scale-only assumption at anchors.
    Pixel anchors are (u, v) coordinates, not (row, col).
    """
    if frame.kind is not DepthKind.RELATIVE:
        raise ValueError('Calibration requires relative depth input')
    anchors = np.asarray(pixel_anchors)
    meters = np.asarray(reference_meters, dtype=np.float64)
    if (anchors.ndim != 2 or anchors.shape[1] != 2 or
        anchors.shape[0] < 2 or meters.shape != (anchors.shape[0],)):
        raise ValueError('At least two paired anchors (u,v) and meters are required')
    if anchors.dtype.kind not in 'iu' or len(np.unique(anchors, axis=0)) != len(anchors):
        raise ValueError('Anchor pixels must be distinct integer positions')
    if not np.isfinite(meters).all() or np.any(meters <= 0):
        raise ValueError('Metric reference distances must be finite and positive')
    if not np.isfinite(max_relative_error) or not 0 <= max_relative_error < 1:
        raise ValueError('max_relative_error must be in [0,1)')
    u, v = anchors[:, 0], anchors[:, 1]
    h, w = frame.values.shape
    if np.any(u < 0) or np.any(u >= w) or np.any(v < 0) or np.any(v >= h):
        raise ValueError('Anchor pixel outside depth image')
    if not frame.mask[v, u].all():
        raise ValueError('Anchor pixel has invalid depth')
    estimated = frame.values[v, u]
    scale = float(np.median(meters / estimated))
    residuals = np.abs(scale * estimated - meters) / meters
    max_error = float(residuals.max())
    if max_error > max_relative_error:
        raise ValueError('Depth anchors inconsistent with a scale-only model')
    return (DepthFrame(frame.values * scale, DepthKind.METRIC, frame.mask),
            ScaleCalibrationReport(scale, len(anchors), max_error))
