"""Offline CLI for traceable, unit-aware depth geometry (no model weights)."""
from __future__ import annotations

import argparse
from dataclasses import asdict
import json
import os
from pathlib import Path
import tempfile

import numpy as np

from representations4d.geometry import (
    CameraIntrinsics, DepthFrame, DepthKind, backproject,
    calibrate_relative_depth, estimate_normals, RigidTransform,
    reproject_depth, temporal_depth_consistency,
)
from representations4d.utils.checkpoint_policy import sha256_file


def _load_depth(path: Path) -> np.ndarray:
    if path.suffix.lower() == '.npy':
        loaded = np.load(path, allow_pickle=False)
        if not isinstance(loaded, np.ndarray):
            raise ValueError('Expected one NPY depth array')
        return loaded
    if path.suffix.lower() == '.npz':
        with np.load(path, allow_pickle=False) as data:
            if 'depth_m' not in data.files or 'units' not in data.files:
                raise ValueError('NPZ input must contain depth_m and units')
            if str(data['units']) != 'm':
                raise ValueError('NPZ input must declare metric depth in meters')
            depth = np.array(data['depth_m'], dtype=np.float64, copy=True)
            if 'valid' in data.files:
                valid = data['valid']
                if valid.shape != depth.shape or valid.dtype != np.bool_:
                    raise ValueError('NPZ validity mask has wrong shape or dtype')
                depth[~valid] = np.nan
            return depth
    raise ValueError('Depth input must be .npy or a metric depth .npz')


def _read_json(path: Path):
    with path.open('r', encoding='utf-8') as f:
        return json.load(f)


def _save_npz_new(path: Path, **arrays) -> None:
    """Durably publish a complete NPZ without overwriting existing evidence."""
    if path.suffix.lower() != '.npz':
        raise ValueError('Output path must end with .npz')
    if not path.parent.is_dir():
        raise FileNotFoundError(f'Output directory does not exist: {path.parent}')
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, suffix='.npz',
                                         prefix='.r4d-', delete=False) as f:
            temp_path = Path(f.name)
            np.savez_compressed(f, **arrays)
            f.flush()
            os.fsync(f.fileno())
        # Link is atomic and fails if output already exists (O_EXCL semantics).
        os.link(temp_path, path)
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def _common_metadata(depth_path: Path, kind: DepthKind) -> dict:
    return {
        'schema': 'representations4d.geometry/1',
        'source_sha256': sha256_file(depth_path),
        'depth_kind_declared': kind.value,
        'depth_provenance': 'user_supplied',
        'coordinate_convention': 'camera X right, Y down, Z forward; pixel centers',
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    for command in ('unproject', 'normals', 'calibrate', 'reproject', 'consistency'):
        cmd = sub.add_parser(command)
        cmd.add_argument('--depth', type=Path, required=True)
        cmd.add_argument('--output', type=Path, required=True)
        if command != 'calibrate':
            cmd.add_argument('--camera', type=Path, required=True,
                             help='JSON with width, height, fx, fy, cx, cy')
            if command in ('unproject', 'normals'):
                cmd.add_argument('--depth-kind', choices=[k.value for k in DepthKind],
                                 required=True)
                cmd.add_argument('--allow-relative', action='store_true')
            else:
                cmd.add_argument('--destination-camera', type=Path, required=True)
                cmd.add_argument('--pose', type=Path, required=True,
                                 help='JSON with rotation [3,3] and translation [3]')
                if command == 'consistency':
                    cmd.add_argument('--current-depth', type=Path, required=True)
        if command == 'unproject':
            cmd.add_argument('--stride', type=int, default=1)
            cmd.add_argument('--max-points', type=int)
        if command == 'calibrate':
            cmd.add_argument('--anchors', type=Path, required=True,
                             help='JSON array of {u, v, depth_m} references')
            cmd.add_argument('--max-relative-error', type=float, default=0.1)
    args = parser.parse_args(argv)

    try:
        depth = _load_depth(args.depth)
        if args.command == 'calibrate':
            if args.depth.suffix.lower() != '.npy':
                raise ValueError('Relative calibration input must be an NPY file')
            frame = DepthFrame(depth, DepthKind.RELATIVE)
            anchors = _read_json(args.anchors)
            pixels = [(a['u'], a['v']) for a in anchors]
            meters = [a['depth_m'] for a in anchors]
            calibrated, report = calibrate_relative_depth(
                frame, pixels, meters, max_relative_error=args.max_relative_error
            )
            metadata = _common_metadata(args.depth, frame.kind)
            metadata['calibration'] = {
                **asdict(report), 'scale_only_assumption': True,
                'anchors_sha256': sha256_file(args.anchors),
                'warning': 'Anchors do not validate metric accuracy between them',
            }
            _save_npz_new(args.output, depth_m=calibrated.values.astype(np.float32),
                          valid=calibrated.mask, units=np.array('m'),
                          metadata=np.array(json.dumps(metadata, sort_keys=True)))
        else:
            kind = (DepthKind.METRIC if args.command in ('reproject', 'consistency')
                    else DepthKind(args.depth_kind))
            if args.depth.suffix.lower() == '.npz' and kind is not DepthKind.METRIC:
                raise ValueError('Metric NPZ input cannot be declared relative')
            frame = DepthFrame(depth, kind)
            camera = CameraIntrinsics(**_read_json(args.camera))
            if kind is DepthKind.RELATIVE and not args.allow_relative:
                raise ValueError('Relative geometry requires --allow-relative')
            metadata = _common_metadata(args.depth, kind)
            metadata['camera'] = asdict(camera)
            metadata['camera_sha256'] = sha256_file(args.camera)
            if args.command in ('reproject', 'consistency'):
                destination_camera = CameraIntrinsics(**_read_json(args.destination_camera))
                pose = RigidTransform(**_read_json(args.pose))
                metadata['destination_camera'] = asdict(destination_camera)
                metadata['destination_camera_sha256'] = sha256_file(args.destination_camera)
                metadata['pose_sha256'] = sha256_file(args.pose)
                metadata['warning'] = ('Input depth is user-declared metric; '
                                       'no camera pose or calibration is inferred')
                if args.command == 'reproject':
                    warped = reproject_depth(frame, camera, destination_camera, pose)
                    metadata['coverage'] = warped.coverage
                    _save_npz_new(args.output, depth_m=warped.depth.values.astype(np.float32),
                                  valid=warped.depth.mask, units=np.array('m'),
                                  metadata=np.array(json.dumps(metadata, sort_keys=True)))
                else:
                    current = DepthFrame(_load_depth(args.current_depth), DepthKind.METRIC)
                    result = temporal_depth_consistency(frame, current, camera,
                                                         destination_camera, pose)
                    metadata['current_source_sha256'] = sha256_file(args.current_depth)
                    metadata['coverage'] = result.coverage
                    _save_npz_new(args.output,
                                  absolute_error=result.absolute_error.astype(np.float32),
                                  relative_error=result.relative_error.astype(np.float32),
                                  valid=result.valid, units=np.array('m'),
                                  metadata=np.array(json.dumps(metadata, sort_keys=True)))
            elif args.command == 'unproject':
                cloud = backproject(frame, camera, stride=args.stride,
                                    max_points=args.max_points,
                                    allow_relative=args.allow_relative)
                metadata['sampling'] = {'stride': args.stride,
                                        'max_points': args.max_points}
                _save_npz_new(args.output, xyz=cloud.xyz.astype(np.float32),
                              uv=cloud.uv.astype(np.float32),
                              units=np.array(cloud.units),
                              metadata=np.array(json.dumps(metadata, sort_keys=True)))
            else:
                normals, valid = estimate_normals(frame, camera)
                _save_npz_new(args.output, normals=normals.astype(np.float32),
                              valid=valid, units=np.array('unit_vector'),
                              metadata=np.array(json.dumps(metadata, sort_keys=True)))
    except (ValueError, TypeError, KeyError, IndexError, OSError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
